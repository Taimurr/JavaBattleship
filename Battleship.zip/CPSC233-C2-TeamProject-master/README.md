
# README
# CPSC233-C2-TeamProject
Team Project

Iteration One can be found in IterationOne branch.
To run the program, run the Game class.

Iteration Two can be found in Iteration2 branch.  
Read the README file on branch Iteration2 for run instructions.

Final Iteration: In Iteration3 and master branch

Run the Game class for the text based version of battleship.  
Run the GameApplication class for the GUI version of battleship.
Ensure the resources folder is in the root directory of the Eclipse project.

